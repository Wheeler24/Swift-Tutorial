import Foundation

let myAge:Int = 22
let yourAge:Int = 20

if myAge > yourAge {
    print("I'm older than you")
} else if myAge < yourAge {
    print("I'm younger than you")
} else {
    print("We are the same age")
}
//plus
let myMothersAge: Int = myAge + 30
let doubleMyAge:Int = myAge * 2

/// 1. unary prefix
let foo:Bool = !true  //takes the 1 value and negates it
/// 2. unary postfix - can create your own with optional vaules
let name = Optional("Corbin")  //name can contain no value or a vaule. That's what optional means
type(of: name)
let unaryPostFix = name!
type(of: unaryPostFix)
/// 3. binary infix - Works with 2 values, infix means in btwn
let result = 1 + 2
let names:String = "Foo " + "Bar"


//TERNARY OPERATOR //
let age = 16
//let message:String
//if age >= 18 {
//    message = "You are an adult"
//} else {
//    message = "You are not an adult"
//}
//print(message)

//let message = CONDITION
//  ? VALUE IF CONDITION IS MET
//  : VALUE IF CONDITION IS NOT YET MET

let message =  age >= 18
    ? "Your are an adult"
    : "You are not yet an adult"
print(message)
