import Foundation

//NOTES//
//Coders like structures better than classes because the complier does not have to create constructors for it.
// Struct have implicit constructor
//Struct don't inheriently allow mutation


struct Person {
    //let or var
    let name: String
    let age: Int
}
let foo = Person(name: "foo", age: 20)

foo.name
foo.age


///Explict Constrcutor
struct CommodoreComputer {
    let name: String
    let manufacturer: String
    init(name: String) {
        self.name = name
        self.manufacturer = "Commodore"
    }
}

let c64 = CommodoreComputer(name: "C64")
c64.name
c64.manufacturer
//c64.name = "Brad" Error because name is let constant

//Works but there is a better way to do this: COMPUTER PROPERTY
//struct PersonTwo {
//    let firstName: String
//    let lastName: String
//    let fullName: String
//    init(firstName: String, lastName: String) {
//        self.firstName = firstName
//        self.lastName = lastName
//        self.fullName = "\(firstName) \(lastName)"
//    }
//}

//Computer Property//
struct PersonTwo {
    let firstName: String
    let lastName: String
    var fullName: String {
        "\(firstName) \(lastName)"
    }
}

let fooBar = PersonTwo(firstName: "Foo", lastName: "Bar")

fooBar.firstName
fooBar.lastName
fooBar.fullName

//Mutable Structures//

struct Car {
    var currentSpeed: Int
    mutating func drive(speed: Int) {
        "Driving..."
        //currentSpeed = speed error: Cannot assign to property: 'currentSpeed' is a 'let' constant
        currentSpeed = speed
        
    }
}

let immutableCar = Car(currentSpeed: 10)
//immutableCar.drive(speed: 20) Error: Cannot use mutating member on immutable value: 'immutableCar' is a 'let' constant


var mutableCar = Car(currentSpeed: 10)
//Taking the value inside mutableCar, which is an instance of Car, and we are assigning it to a new let constant called copy. Struct's are value types so if you assign an instance of any struct to another variable the internal data of the struct will be copyed over to the copy variable.
//You have duplicate Car
let copy = mutableCar
mutableCar.drive(speed: 30)
mutableCar.currentSpeed
copy.currentSpeed


//Structures cannot subclass other structs//

struct LivingThing {
    init() {
        "I'm a living thing"
    }
}

//struct Animal: LivingThing {} Error: Inheritance from non-protocol type 'LivingThing'

//GAP LOGIC//
struct Bike {
    let manufacturer: String
    let currentSpeed: Int
    
    func copy(currentSpeed: Int) -> Bike {
        Bike(manufacturer: self.manufacturer, currentSpeed: currentSpeed)
    }
}

let bikeOne = Bike(manufacturer: "HD", currentSpeed: 20)

let bikeTwo = bikeOne.copy(currentSpeed: 30)
bikeOne.currentSpeed
bikeTwo.currentSpeed

