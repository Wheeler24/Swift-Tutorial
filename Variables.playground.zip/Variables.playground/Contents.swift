import Foundation

let myName:String = "Vandad"
let yourName:String = "Corbin"

var names:Array = [myName, yourName]

//names = ["Bla"]
names.append("Bar")
names.append("Baz")

print(names)


let foo = "Foo"
var foo2 = foo

foo2 = "Foo 2"
foo
foo2

let moreNames:Array = ["Foo", "Bar"]

var copy = moreNames
copy.append("Baz")
print(moreNames)
print(copy)

//----------------------------->
//If working with a let constant and if it's internal value is an instance of a class,
// the class can mutate internally without the let constant getting in the way

//EXAMPLE
//NS Mutable Array//

let oldArray = NSMutableArray(
    array: [
        "Foo",
        "Bar"
    ]
)
oldArray.add("Baz") //with NS Mutable array can't use append because oldArray is a let constant.
//have to use add
var newArray = oldArray
//newArray got the value of oldArray
newArray.add("Qux")
//Expect only newArray to have "Qux" but both have it
// newArray and oldArray are now same array
print(oldArray)
print(newArray)
//Very confusing with NS Mutable Array


//----------------------------->
//Be careful with mutable types
let someNames = NSMutableArray(
    array: [
        "Foo",
        "Bar"
    ]
)
//Changing the original copy of someNames array
func changeTheArray(_ array: NSArray) {
    let arrayTwo = array as! NSMutableArray //REALLY BAD CODE just a demo
    arrayTwo.add("Baz")
}

changeTheArray(someNames)
print(someNames)


//If you assign a class to a let constant the class can internally change
