import Foundation

struct Person {
    let firstName: String?
    let lastName: String?
    
    enum Errors: Error {
        case firstNameIsNil
        case lastNameIsNil
        case bothNamesAreNil
    }
    
    func getFullName() throws -> String {
//        if let firstName, let lastName {
//            "\(firstName) \(lastName)"
//        } else if firstName == nil, lastName != nil {
//            throw Errors.firstNameIsNil
//        }
        switch(firstName, lastName) {
        case (.none, .none):
            throw Errors.bothNamesAreNil
        case (.none, .some):
            throw Errors.firstNameIsNil
        case (.some, .none):
            throw Errors.lastNameIsNil
        case let (.some(firstName), .some(lastName)):
            return "\(firstName) \(lastName)"
        }
    }
}

let foo = Person(firstName: "foo", lastName: nil)
do {
    let fullName = try foo.getFullName()
} catch let e {
    "Got an error = \(e)"
}

do {
    let fullName = try foo.getFullName()
    fullName
} catch is Person.Errors {
    "Got an error"
}

let bar = Person(firstName: nil, lastName: nil)
do {
    let fullName = try bar.getFullName()
    fullName
} catch Person.Errors.firstNameIsNil {
    "First Name is nil"
} catch Person.Errors.lastNameIsNil {
    "Last name is nil"
} catch Person.Errors.bothNamesAreNil {
    "Both names are nil"
} catch {
    "Some other error was thrown"
}

struct Car {
    let manufacturer: String
    
    enum Errors: Error {
        case invalidManufacturer
    }
    
    init(manufacturer: String) throws {
        if manufacturer.isEmpty {
            throw Errors.invalidManufacturer
        }
        self.manufacturer = manufacturer
    }
}
//Best way for error handeling
    do {
        let myCar = try Car(manufacturer: "")
        myCar
        myCar.manufacturer
    } catch Car.Errors.invalidManufacturer {
        "Invalid manufacutere"
    } catch {
        "Some other error"
    }
//2nd best way
if let yourCar = try? Car(manufacturer: "Tesla") {
    "Success, your car = \(yourCar)"
} else {
    "Failed to construct and error is not accessible now"
}
//NEVER DO THIS unless a valid reason
let theirCar = try! Car(manufacturer: "Ford")
theirCar.manufacturer


//EX3//
struct Dog {
    let isInjured: Bool
    let isSleeping: Bool
    
    enum BarkingErrors: Error {
        case cannotBarkIsSleeping
    }
    
    enum RunningErrors: Error {
        case cannotRunIsInjured
    }
    
    func bark() throws {
        if isSleeping {
            throw BarkingErrors.cannotBarkIsSleeping
        }
        "Bark..."

    }
    
    func run() throws {
        if isInjured {
            throw RunningErrors.cannotRunIsInjured
        }
        "Running..."
    }
//Function with throws you can use try statements and don't have to wrap them into do catch blocks.
    func barkAndRun() throws {
//        do {
//            try bark()
//        } catch {
//            //do your api call
//        }
        try bark()
        try run()
    }
}

let dog = Dog(isInjured: true, isSleeping: true)
//let dog = Dog(isInjured: false, isSleeping: false)


do {
    try dog.barkAndRun()
    dog
//Only the first error will be caught
//Only bark() will only throw an error
} catch Dog.BarkingErrors.cannotBarkIsSleeping,
        Dog.RunningErrors.cannotRunIsInjured {
    "Cannont-bark-is-sleeping OR cannot-run-is-injured"
} catch {
    "Some other error"
}

do {
    try dog.barkAndRun()
    dog
//Only the first error will be caught
//Only bark() will only throw an error
} catch Dog.BarkingErrors.cannotBarkIsSleeping {
    "Cannont-bark-is-sleeping"
} catch Dog.RunningErrors.cannotRunIsInjured {
        "cannot-run-is-injured"
}
  catch {
    "Some other error"
}


//RE THROWS//
//Func that internally call another function that can thrpw
func fullName(firstName: String?, lastName: String?, calculator: (String?, String?) throws -> String?) 
    rethrows -> String? {
    try calculator(firstName, lastName)
}

enum NameErrors: Error {
    case firstNameIsInvalid
    case lastNameIsinvalid
}

func + (firstName: String?, lastName: String?) throws -> String? {
    guard let firstName, !firstName.isEmpty else {
        throw NameErrors.firstNameIsInvalid
    }
    guard let lastName, !lastName.isEmpty else {
        throw NameErrors.lastNameIsinvalid
    }
    return "\(firstName) \(lastName)"
}


do {
    let fooBar = try fullName(firstName: nil, lastName: nil, calculator: +)
//    let fooBar = try fullName(firstName: "Foo", lastName: nil, calculator: +)
//    let fooBar = try fullName(firstName: nil, lastName: "Bar", calculator: +)
//    let fooBar = try fullName(firstName: "Foo", lastName: "Bar", calculator: +)
} catch NameErrors.firstNameIsInvalid {
    "First name is invalid"
} catch NameErrors.lastNameIsinvalid {
    "Last name is invalid"
} catch let err {
    "Some other error = \(err)"
}


//RESULTS//
//Kind of related to error handeling. Doesn't throw an error but carry an error with it
enum IntegerErrors: Error {
    case noPositiveIntBefore(thisValue: Int)
}

func getPreviousPositiveInt(from int: Int
) -> Result<Int, IntegerErrors> {
    guard int > 0 else {
        return Result.failure(IntegerErrors.noPositiveIntBefore(thisValue: int))
    }
    return Result.success(int-1)
}

func performGet(forValue value: Int) {
    switch getPreviousPositiveInt(from: value) {
    case let .success(previousValue):
        "Previous value is \(previousValue)"
    case let .failure(error):  //because a Result is an enum you can have a switch in a switch
        switch error {
        case let .noPositiveIntBefore(thisValue): "No positive integer before \(thisValue)"
        }
    }
}

//performGet(forValue: 0)
performGet(forValue: 2)
