import Foundation
//DATA TYPES
/*
//String
"Hi how are you?"

//Int
12
34

//Double
2.3456
3.1415

//Bool
true false
*/
/*
//Intalizing Data Types
var myVar:String = "Hi"
myVar = "Bye"
print(myVar)

var myInt:Int = 20
myInt += 1
print(myInt)

var cVar = "Hi"
print(cVar)

let myConst:String = "Hello"
print(myConst)
*/
//Math Stuff
/*
var a:Double = 2.3
var b:Double = 5.8
//var c2 = a%b
var c = pow(a,b) //For pow to work the variables have to be the double Data type
var d = sqrt(a)
var e = floor(a)
var f = ceil(b)
print(c, d, e, f)
*/
//EXAMPLE DONE ON OWN
/*
var taxPercent:Double = 8.33
taxPercent = taxPercent / 100
let subTotal:Double = 15


var total:Double = ((taxPercent * subTotal) + subTotal)/3

print(total)
*/

//FUNCTIONS
/*
 //EXAMPLE ONE
func myFunc(a:Int){
    //let a = 10
    let b = 5
    
    print(a+b)
}

//Function Calling
myFunc(a: 10)
*/
//FUNCTIONS
/*
func myFunc(a:Int)->Int{
    //let a = 10
    let b = 5
    
    return(a+b)
}

//Function Calling
print(myFunc(a: 10))
*/
//EX3
/*
func myFunc(a:Int, b:Int)->Int{
    
    
    return(a+b)
}

//Function Calling
print(myFunc(a: 10, b: 5))
*/

//Argument labels:
/*
func myFunc(first a:Int, second b:Int)->Int{
    
    
    return(a+b)
}

//Function Calling
print(myFunc(first: 10, second: 5))
*/
/*
func myFunc(_ a:Int, _ b:Int=0)->Int{  //b:Int = 0 is Function overloading
    
    
    return(a+b)
}

func myFunc(first a:Int, second b:Int)->Int{
    
    
    return(a-b)
}

//Function Calling
print(myFunc(5,10))
print(myFunc(first: 10, second: 5))
*/
//****Pracitce I did on own****
/*
func totalPerPerson(_ subTotal:Double, _ taxRate:Double, _ numOfFriends:Int)->Double{
    var taxPercent = taxRate / 100


   var total:Double = ((taxPercent * subTotal) + subTotal)/3
    
    return total
    
}

print(totalPerPerson(15, 8.33, 3))
*/

//****STRUCTURES****\\
struct ChatView{
    //variables and conditions: PROPERTIES
    var msg:String = "Rose is still alive"
    
    //completed property
    var msgWithPrefix:String{
        return "Jack says "+msg
    }
    
    //UI code: View Code
    
    
    //functions: METHODS
    func sentChat(){
        //code to send chat
        print(msg)
        print(msgWithPrefix)
    }
    
    
    func deleteChat(){
        //code to delete in chat
        print(msg)
        print(msgWithPrefix)
    }
}
