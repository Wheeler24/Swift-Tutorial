import Foundation

// DEF: Clousers are a specical types of function in line so you can pass them to another function and hold another function. They are like function references

//func add(_ lhs: Int, _ rhs: Int) -> Int {
//    lhs + rhs
//}


let add: (Int, Int) -> Int
= { (lhs: Int, rhs: Int) -> Int in
    lhs + rhs
}
add(20, 30)

//Power of closures: you can pass any function in line
func customAdd (
    _ lhs: Int,
    _ rhs: Int,
    using function: (Int, Int) -> Int
) -> Int {
    function(lhs, rhs)
}
///BEST WAY TO WRITE CLOSURES
//The clousre is the last thing in a argument list
//passed 20 and 30 to lhs and rhs
customAdd(20, 30
         ) { (lhs: Int, rhs: Int) -> Int in
            lhs + rhs
        }
//Called clean up but makes it easier for other programmers to know the type
//Less information you give to the compiler it takes longer.
customAdd(20, 30
         ) { (lhs, rhs) in
            lhs + rhs
        }

customAdd(20, 30
         ) {
            $0 + $1
        }

///PASSING SPECIAL CLOSURE TO FUNC
let ages = [30, 20, 19, 40]
ages.sorted(by: {(lhs: Int, rhs: Int) -> Bool in
    lhs > rhs
})

//OR

let newAges = [30, 20, 19, 40]
newAges.sorted(by: <)

func customAdd2(
    _ lhs: Int,
    _ rhs: Int,
    using function: (Int, Int) -> Int
) -> Int {
    function(lhs, rhs)
}

//Pass functions to closures
func add10to(_ value: Int) -> Int {
    value + 10
}

func add20To(_ value: Int) -> Int {
    value + 20
}
    
func doAddition(on value: Int,
    using function: (Int) -> Int
) -> Int {
    return function(value)
}

doAddition(on: 20) { (value) in
    value + 30
}

doAddition(on: 20, using: add10to(_:))

doAddition(on: 20, using: add20To(_:))


