import Foundation

func noArgumentAndNoReturnValue() {
    "I don't know what I am doing"
}
noArgumentAndNoReturnValue()


func plusTwo(value: Int) {
    let newValue = value + 2
}

plusTwo(value: 30)

func newPlusTwo(value: Int) -> Int{
    return value + 2
}

newPlusTwo(value: 30)

func customAdd (value1: Int, value2: Int) -> Int {
        value1 + value2
    }
let customAdded = customAdd(value1: 10, value2: 20)


func customMinus (_ lhs: Int, _ rhs: Int) -> Int {
    lhs - rhs
}

let customeSubtracted = customMinus (20, 10)

//In pure swift you will get a warning becuase:
//  You are calling a function without consuming its result
//  We don't see that in a playground is because a playgroud consumes     results implicitly
let added = customAdd(value1: 20, value2: 30)


@discardableResult
func myCustomAdd(_ lhs: Int, _ rhs: Int) -> Int {
    lhs + rhs
}

myCustomAdd(20, 30)

//mainLogic function can only be called in the doSomethingComplicated Function
func doSomethingComplicated(with value: Int) -> Int {
    func mainLogic(value: Int) -> Int {
        value + 2
    }
    return mainLogic(value: value + 3)
}
doSomethingComplicated(with: 30)


func getFullName (
    firstName: String = "Corbin",
    lastName: String = "Fanning") -> String {
    "\(firstName) \(lastName)"
}
getFullName()
getFullName(firstName: "Wade")
getFullName(lastName: "Taylor")
getFullName(firstName: "Wade", lastName: "Taylor")


