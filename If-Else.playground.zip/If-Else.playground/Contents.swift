import Foundation

let myName:String = "Vandad"
let myAge:Int = 21
let yourName:String = "Corbin"
let yourAge:Int = 20

if myName == "vandad" {
    print("Your name is \(myName)")
} else {
    print("Oops I got your named wrong.")
}

if myName == "Vandad" {
    print("Now I guessed it correctly.")
} else if myName == "Corbin" {
    print("Are you Corbin?")
} else {
    print("Ok I give up.")
}


if "Corbin" == yourName {
    "Old way of doing things."
}

//More Complicated

if myName == "Vandad" && myAge == 30 {
    "My name is Vandad and my age is 30."
} else if myAge == 20 {
    "I only guessed the age right."
} else {
    "I give up"
}

//Or means if one is true the whole thing is true. Which means all have to be false
if myAge == 20 || myName == "Vandad" {
    "Either age is 20, or name is Corbin or both"
} else if myName == "Vandad" || myAge == 20 {
    "It's to late to get in this clause"
}


//Mixing AND and OR
// (myName == "Vandad" && myAge == 22 && yourName == "Corbin") = false || (yourAge == 20)= true
//Output = true
if myName == "Vandad"
    && myAge == 22
    && yourName == "Corbin"
    || yourAge == 20 {
    "My name is Vandad and I'm 22 and your name is Corbin...OR...you are 20"
}
//Returns false
if (myName == "Vandad"
    && myAge == 22)
    &&
    (yourName == "Corbin"
     || yourAge == 20) {
    "My name is Vandad and I'm 22 ...AND... your name is Corbin or you are 20."
} else {
    "Well that didn't work."
}

//Returns true
if (myName == "Vandad"
    && myAge == 22)
    ||
    (yourName == "Corbin"
     || yourAge == 20) {
    "My name is Vandad and I'm 22 ...AND... your name is Corbin or you are 20."
} else {
    "Well that didn't work."
}
