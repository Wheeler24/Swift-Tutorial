import UIKit
//DECLARING CONSTANTS AND VARIABLES
// let = constant variable
/*
let a = 2
//var = variable
var b = 4

b = a
//a = b  Will not work because a is a let (constant) variable


var environment = "development"
let maxNumOfLoginAttemps: Int

if environment == "development" {
    maxNumOfLoginAttemps = 100
} else {
    maxNumOfLoginAttemps = 10
}
//Now maxNumOfLoginAttemps, and can be read

//Declaring multiple varables
//var x = 0.0, y = 0.0, z = 0.0

var welcomeMessage: String
welcomeMessage = "Hello"
//Example
var red, green, blue: Double
//My example
var num1, num2, num3: Float
var author, title, ISBN: String
var checkIn, checkout: Bool


let 🤜🏻🤛🏻 = "fistbump"
let 🍌🍰 = "bannana pie"
//let ☀️☕️ = "morning coffee"
let 🥵🐶 = "hotdog"
*/

/* Naming Conventions: Cannot contain whitespace characters, math symbols, arrows, private-use Unicode scalar varables, or line- and box-drawings characters
*/

//Example
/*
var friendlyWelcome = "Hello!"
friendlyWelcome = "Hola!"
friendlyWelcome = "Bojour!"
print("The current value of friendlyWelocme is \(friendlyWelcome)")

//My Example
var s = 5, p = 10
print(s != p)
print("\(s) plus \(p) = \(s + p)")
*/
//SEMICOLONS
//let cat = "🐱"; print(cat)
// I don't perfer this way.

//INTEGER BOUNDS
/*
let minValue = UInt8.min //minValue is equal to 0, and is of type UInt8
let maxValue = UInt8.max //maxValue is equal to 255, and is of type UInt8
//Int8 goes up to 256 but Max value is 255 because it starts at 0 NOT 1!

//Double is a 64-bit floating-point number
    //Double is at least 15 decimal digits
    
//Float is a 32-bit floating-point number
    //Float can be as little as 6 decemial digits
//Double is prefered when both types are appropriate

let meaningOfLife = 42
// this variable is infered to be of type Int

let pi = 3.14159
//infered to be of type Double because if you don't specify the type for a floating-point literal, Swift infers it to be a double

let anotherPi = 3 + 0.14159
// this is also inferred to be of type Double
*/
/*
//NUMEROC LITERALS
    //Example
let decInt = 17
let binaryInt = 0b10001
let octalInt = 0o21
let hexadecInt = 0x11

    //My example
let decInt2 = 20
let binaryInt2 = 0b10100
let octalInt2 = 0o24
let hexadecInt2 = 0x14
    //Example
let decDouble = 12.1875
let exponentDouble = 1.21875e1
let hexdecDouble = 0xC.3p0
    //Example
let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1
*/

//NUMERIC TYPE CONVERSIONS
    //Int Converstions
let cannotBeNegative: UInt8 = -1
//UInt8 can't be store negative numbers but only numbers btwn 0 - 255. So an error will occur.
let tooBig: Int8 = Int8.max + 1
//Int8 can't store a number larger than the max number which is 127. So an error will occur.





