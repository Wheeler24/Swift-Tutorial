import Foundation

//OPTIONALS//
//Def: Optionals indicate a value that could or could not be present

//func multipleByTwo(_ value: Int) ->Int {
//    value * 2
//}
//multipleByTwo()  -  Have to pass a value to function

func multipleByTwo(_ value: Int? = nil) ->Int {
    //syntax for unwrapping a optional
    //(There are other ways of doing this)
    if let value {
        return value * 2
    } else {
        return 0
    }
}

multipleByTwo()
multipleByTwo(nil)
multipleByTwo(4)

let age: Int? = nil
if age != nil {
    "Age is there! How odd!"
} else {
    "Age is nil which is correct!"
}

if let age {
    "Age is there. How odd! Its value is \(age)"
} else {
    "No age is present, as expected"
}

//GAURD
func checkAge() {
    guard age != nil else {
        "Age is nil as expected"
        return
    }
    "Age is not nil here. Strange"
}

checkAge()

//GUARD LET - Unwraps an optional
let age2: Int? = 0
//let age2: Int? = nil
func checkAge2() {
    guard let age2 else {
        "Age2 is nil. How strange"
        return
    }
    "Age2 is not nil as expected. Value = \(age2)"
}
checkAge2()

//*****************
//Optionals are a instance of an enumeration called optionals lol
switch age {
case .none:
    "Age has no value as expected"
    break
case let .some(value):
    "Age has the value of \(value)"
    break
}
//don't assume age2 is optional
if age2 == 0 {
    "Age 2 is 0 as expected, and it not nil"
} else {
    "Age2 is not 0. How strange!"
}
//Coders know that age2 is an optional
if age2 == .some(0) {
    "Age 2 is 0 as expected, and it not nil"
} else {
    "Age2 is not 0. How strange!"
}

//OPTIONAL CHAINING
struct Person {
    let name: String
    
    let address: Address?
    struct Address {
        let firstLine: String?
    }
}
//If you put and address in it does not work??
let foo: Person = Person(name: "Foo", address: nil)

if let fooFirstAddressLine = foo.address?.firstLine {
    fooFirstAddressLine
} else {
    "Foo does not have an address with the first line. AS expected"
}

if let fooAddress = foo.address,
   let firstLine = fooAddress.firstLine {
    fooAddress
    firstLine
}

let bar: Person? = Person(name: "Bar", address: nil)

if bar?.name == "Bar", bar?.address?.firstLine == nil {
    "Bar's name is Bar and has no first line of address"
} else {
    "Seems like something isn't working right!"
}

//SWITCH Optionals
let baz: Person? = Person(name: "Baz", address: Person.Address(firstLine: "Baz first line"))

switch baz?.address?.firstLine{
case let .some(firstLine) where firstLine.starts(with: "Baz"):
    "Baz first address line = \(firstLine)"
case let .some(firstLine):
    "Baz first address line that didn't match the previous case"
case .none:
    "Baz first address line is nil???"
}
//If let
//func getFullName(firstName: String, lastName: String?) -> String? {
//    if let lastName {
//        return "\(firstName) \(lastName)"
//    } else {
//        return nil
//    }
//}

//getFullName(firstName: "Foo", lastName: nil)
//getFullName(firstName: "Foo", lastName: "Bar")

//Guard let
func getFullName(firstName: String, lastName: String?) -> String? {
    guard let lastName else{
        return nil
    }
    return "\(firstName) \(lastName)"
}

getFullName(firstName: "Foo", lastName: nil)
getFullName(firstName: "Foo", lastName: "Bar")
